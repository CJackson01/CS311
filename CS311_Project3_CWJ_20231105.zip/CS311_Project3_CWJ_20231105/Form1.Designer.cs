﻿namespace CS311_Project3_CWJ_20231105
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lbl_BUPizzaPalace = new Label();
            cbo_size = new ComboBox();
            lbl_size = new Label();
            lbl_crusttype = new Label();
            rdo_crusttype_thin = new RadioButton();
            rdo_crusttype_thick = new RadioButton();
            rdo_crusttype_regular = new RadioButton();
            lbl_toppings = new Label();
            ckb_toppings_pepperoni = new CheckBox();
            ckb_toppings_sausage = new CheckBox();
            ckb_toppings_canadianbacon = new CheckBox();
            ckb_toppings_spicyitaliansausage = new CheckBox();
            ckb_toppings_onion = new CheckBox();
            ckb_toppings_greenpepper = new CheckBox();
            ckb_toppings_blackolives = new CheckBox();
            ckb_toppings_greenolives = new CheckBox();
            ckb_toppings_bananapeppers = new CheckBox();
            ckb_toppings_jalepeno = new CheckBox();
            ckb_toppings_extracheese = new CheckBox();
            ckb_toppings_mushrooms = new CheckBox();
            lbl_ordersummary = new Label();
            lbl_subtotal = new Label();
            lbl_tax = new Label();
            lbl_Total = new Label();
            rtf_ordersummary = new RichTextBox();
            rtf_subtotal = new RichTextBox();
            rtf_tax = new RichTextBox();
            rtf_total = new RichTextBox();
            btn_calculate = new Button();
            pict_pizzaimage = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pict_pizzaimage).BeginInit();
            SuspendLayout();
            // 
            // lbl_BUPizzaPalace
            // 
            lbl_BUPizzaPalace.AutoSize = true;
            lbl_BUPizzaPalace.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_BUPizzaPalace.Location = new Point(334, 32);
            lbl_BUPizzaPalace.Name = "lbl_BUPizzaPalace";
            lbl_BUPizzaPalace.Size = new Size(378, 65);
            lbl_BUPizzaPalace.TabIndex = 0;
            lbl_BUPizzaPalace.Text = "BU Pizza Palace";
            // 
            // cbo_size
            // 
            cbo_size.FormattingEnabled = true;
            cbo_size.Items.AddRange(new object[] { "Small: $2.00", "Medium: $5.00", "Large: $10.00", "XLarge: $15.00", "Ginormous: $20.00" });
            cbo_size.Location = new Point(62, 118);
            cbo_size.Name = "cbo_size";
            cbo_size.Size = new Size(121, 23);
            cbo_size.TabIndex = 1;
            cbo_size.Text = "Choose Size";
            // 
            // lbl_size
            // 
            lbl_size.AutoSize = true;
            lbl_size.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_size.Location = new Point(62, 100);
            lbl_size.Name = "lbl_size";
            lbl_size.Size = new Size(30, 15);
            lbl_size.TabIndex = 2;
            lbl_size.Text = "Size";
            // 
            // lbl_crusttype
            // 
            lbl_crusttype.AutoSize = true;
            lbl_crusttype.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_crusttype.Location = new Point(257, 118);
            lbl_crusttype.Name = "lbl_crusttype";
            lbl_crusttype.Size = new Size(65, 15);
            lbl_crusttype.TabIndex = 3;
            lbl_crusttype.Text = "Crust Type";
            // 
            // rdo_crusttype_thin
            // 
            rdo_crusttype_thin.AutoSize = true;
            rdo_crusttype_thin.Location = new Point(349, 121);
            rdo_crusttype_thin.Name = "rdo_crusttype_thin";
            rdo_crusttype_thin.Size = new Size(49, 19);
            rdo_crusttype_thin.TabIndex = 4;
            rdo_crusttype_thin.Text = "Thin";
            rdo_crusttype_thin.UseVisualStyleBackColor = true;
            // 
            // rdo_crusttype_thick
            // 
            rdo_crusttype_thick.AutoSize = true;
            rdo_crusttype_thick.Location = new Point(403, 122);
            rdo_crusttype_thick.Name = "rdo_crusttype_thick";
            rdo_crusttype_thick.Size = new Size(55, 19);
            rdo_crusttype_thick.TabIndex = 5;
            rdo_crusttype_thick.Text = "Thick";
            rdo_crusttype_thick.UseVisualStyleBackColor = true;
            // 
            // rdo_crusttype_regular
            // 
            rdo_crusttype_regular.AutoSize = true;
            rdo_crusttype_regular.Checked = true;
            rdo_crusttype_regular.Location = new Point(462, 122);
            rdo_crusttype_regular.Name = "rdo_crusttype_regular";
            rdo_crusttype_regular.Size = new Size(68, 19);
            rdo_crusttype_regular.TabIndex = 6;
            rdo_crusttype_regular.TabStop = true;
            rdo_crusttype_regular.Text = "Regular";
            rdo_crusttype_regular.UseVisualStyleBackColor = true;
            // 
            // lbl_toppings
            // 
            lbl_toppings.AutoSize = true;
            lbl_toppings.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_toppings.Location = new Point(65, 174);
            lbl_toppings.Name = "lbl_toppings";
            lbl_toppings.Size = new Size(56, 15);
            lbl_toppings.TabIndex = 7;
            lbl_toppings.Text = "Toppings";
            // 
            // ckb_toppings_pepperoni
            // 
            ckb_toppings_pepperoni.AutoSize = true;
            ckb_toppings_pepperoni.Location = new Point(65, 202);
            ckb_toppings_pepperoni.Name = "ckb_toppings_pepperoni";
            ckb_toppings_pepperoni.Size = new Size(83, 19);
            ckb_toppings_pepperoni.TabIndex = 8;
            ckb_toppings_pepperoni.Text = "Pepperoni";
            ckb_toppings_pepperoni.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_sausage
            // 
            ckb_toppings_sausage.AutoSize = true;
            ckb_toppings_sausage.Location = new Point(65, 229);
            ckb_toppings_sausage.Name = "ckb_toppings_sausage";
            ckb_toppings_sausage.Size = new Size(71, 19);
            ckb_toppings_sausage.TabIndex = 9;
            ckb_toppings_sausage.Text = "Sausage";
            ckb_toppings_sausage.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_canadianbacon
            // 
            ckb_toppings_canadianbacon.AutoSize = true;
            ckb_toppings_canadianbacon.Location = new Point(65, 254);
            ckb_toppings_canadianbacon.Name = "ckb_toppings_canadianbacon";
            ckb_toppings_canadianbacon.Size = new Size(112, 19);
            ckb_toppings_canadianbacon.TabIndex = 10;
            ckb_toppings_canadianbacon.Text = "Canadian Bacon";
            ckb_toppings_canadianbacon.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_spicyitaliansausage
            // 
            ckb_toppings_spicyitaliansausage.AutoSize = true;
            ckb_toppings_spicyitaliansausage.Location = new Point(65, 279);
            ckb_toppings_spicyitaliansausage.Name = "ckb_toppings_spicyitaliansausage";
            ckb_toppings_spicyitaliansausage.Size = new Size(140, 19);
            ckb_toppings_spicyitaliansausage.TabIndex = 11;
            ckb_toppings_spicyitaliansausage.Text = "Spicy Italian Sausage";
            ckb_toppings_spicyitaliansausage.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_onion
            // 
            ckb_toppings_onion.AutoSize = true;
            ckb_toppings_onion.Location = new Point(217, 202);
            ckb_toppings_onion.Name = "ckb_toppings_onion";
            ckb_toppings_onion.Size = new Size(59, 19);
            ckb_toppings_onion.TabIndex = 12;
            ckb_toppings_onion.Text = "Onion";
            ckb_toppings_onion.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_greenpepper
            // 
            ckb_toppings_greenpepper.AutoSize = true;
            ckb_toppings_greenpepper.Location = new Point(217, 227);
            ckb_toppings_greenpepper.Name = "ckb_toppings_greenpepper";
            ckb_toppings_greenpepper.Size = new Size(104, 19);
            ckb_toppings_greenpepper.TabIndex = 13;
            ckb_toppings_greenpepper.Text = "Green Pepper";
            ckb_toppings_greenpepper.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_blackolives
            // 
            ckb_toppings_blackolives.AutoSize = true;
            ckb_toppings_blackolives.Location = new Point(217, 254);
            ckb_toppings_blackolives.Name = "ckb_toppings_blackolives";
            ckb_toppings_blackolives.Size = new Size(93, 19);
            ckb_toppings_blackolives.TabIndex = 14;
            ckb_toppings_blackolives.Text = "Black Olives";
            ckb_toppings_blackolives.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_greenolives
            // 
            ckb_toppings_greenolives.AutoSize = true;
            ckb_toppings_greenolives.Location = new Point(217, 279);
            ckb_toppings_greenolives.Name = "ckb_toppings_greenolives";
            ckb_toppings_greenolives.Size = new Size(98, 19);
            ckb_toppings_greenolives.TabIndex = 15;
            ckb_toppings_greenolives.Text = "Green Olives";
            ckb_toppings_greenolives.UseVisualStyleBackColor = true;
            ckb_toppings_greenolives.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // ckb_toppings_bananapeppers
            // 
            ckb_toppings_bananapeppers.AutoSize = true;
            ckb_toppings_bananapeppers.Location = new Point(349, 202);
            ckb_toppings_bananapeppers.Name = "ckb_toppings_bananapeppers";
            ckb_toppings_bananapeppers.Size = new Size(114, 19);
            ckb_toppings_bananapeppers.TabIndex = 16;
            ckb_toppings_bananapeppers.Text = "Banana Peppers";
            ckb_toppings_bananapeppers.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_jalepeno
            // 
            ckb_toppings_jalepeno.AutoSize = true;
            ckb_toppings_jalepeno.Location = new Point(349, 229);
            ckb_toppings_jalepeno.Name = "ckb_toppings_jalepeno";
            ckb_toppings_jalepeno.Size = new Size(75, 19);
            ckb_toppings_jalepeno.TabIndex = 17;
            ckb_toppings_jalepeno.Text = "Jalepeno";
            ckb_toppings_jalepeno.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_extracheese
            // 
            ckb_toppings_extracheese.AutoSize = true;
            ckb_toppings_extracheese.Location = new Point(349, 254);
            ckb_toppings_extracheese.Name = "ckb_toppings_extracheese";
            ckb_toppings_extracheese.Size = new Size(98, 19);
            ckb_toppings_extracheese.TabIndex = 18;
            ckb_toppings_extracheese.Text = "Extra Cheese";
            ckb_toppings_extracheese.UseVisualStyleBackColor = true;
            // 
            // ckb_toppings_mushrooms
            // 
            ckb_toppings_mushrooms.AutoSize = true;
            ckb_toppings_mushrooms.Location = new Point(349, 279);
            ckb_toppings_mushrooms.Name = "ckb_toppings_mushrooms";
            ckb_toppings_mushrooms.Size = new Size(91, 19);
            ckb_toppings_mushrooms.TabIndex = 19;
            ckb_toppings_mushrooms.Text = "Mushrooms";
            ckb_toppings_mushrooms.UseVisualStyleBackColor = true;
            // 
            // lbl_ordersummary
            // 
            lbl_ordersummary.AutoSize = true;
            lbl_ordersummary.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_ordersummary.Location = new Point(62, 331);
            lbl_ordersummary.Name = "lbl_ordersummary";
            lbl_ordersummary.Size = new Size(99, 15);
            lbl_ordersummary.TabIndex = 20;
            lbl_ordersummary.Text = "Order Summary:";
            // 
            // lbl_subtotal
            // 
            lbl_subtotal.AutoSize = true;
            lbl_subtotal.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_subtotal.Location = new Point(340, 349);
            lbl_subtotal.Name = "lbl_subtotal";
            lbl_subtotal.Size = new Size(58, 15);
            lbl_subtotal.TabIndex = 21;
            lbl_subtotal.Text = "SubTotal:";
            // 
            // lbl_tax
            // 
            lbl_tax.AutoSize = true;
            lbl_tax.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_tax.Location = new Point(368, 379);
            lbl_tax.Name = "lbl_tax";
            lbl_tax.Size = new Size(29, 15);
            lbl_tax.TabIndex = 22;
            lbl_tax.Text = "Tax:";
            // 
            // lbl_Total
            // 
            lbl_Total.AutoSize = true;
            lbl_Total.Location = new Point(360, 410);
            lbl_Total.Name = "lbl_Total";
            lbl_Total.Size = new Size(37, 15);
            lbl_Total.TabIndex = 23;
            lbl_Total.Text = "Total:";
            // 
            // rtf_ordersummary
            // 
            rtf_ordersummary.Location = new Point(65, 349);
            rtf_ordersummary.Name = "rtf_ordersummary";
            rtf_ordersummary.Size = new Size(249, 138);
            rtf_ordersummary.TabIndex = 24;
            rtf_ordersummary.Text = "";
            // 
            // rtf_subtotal
            // 
            rtf_subtotal.Location = new Point(403, 349);
            rtf_subtotal.Name = "rtf_subtotal";
            rtf_subtotal.Size = new Size(100, 24);
            rtf_subtotal.TabIndex = 25;
            rtf_subtotal.Text = "";
            // 
            // rtf_tax
            // 
            rtf_tax.Location = new Point(403, 379);
            rtf_tax.Name = "rtf_tax";
            rtf_tax.Size = new Size(100, 25);
            rtf_tax.TabIndex = 26;
            rtf_tax.Text = "";
            // 
            // rtf_total
            // 
            rtf_total.Location = new Point(403, 410);
            rtf_total.Name = "rtf_total";
            rtf_total.Size = new Size(100, 24);
            rtf_total.TabIndex = 27;
            rtf_total.Text = "";
            // 
            // btn_calculate
            // 
            btn_calculate.Location = new Point(334, 440);
            btn_calculate.Name = "btn_calculate";
            btn_calculate.Size = new Size(169, 47);
            btn_calculate.TabIndex = 28;
            btn_calculate.Text = "Calculate";
            btn_calculate.UseVisualStyleBackColor = true;
            btn_calculate.Click += Click_Order_Pizza;
            // 
            // pict_pizzaimage
            // 
            pict_pizzaimage.Image = (Image)resources.GetObject("pict_pizzaimage.Image");
            pict_pizzaimage.Location = new Point(60, 32);
            pict_pizzaimage.Name = "pict_pizzaimage";
            pict_pizzaimage.Size = new Size(101, 45);
            pict_pizzaimage.SizeMode = PictureBoxSizeMode.StretchImage;
            pict_pizzaimage.TabIndex = 29;
            pict_pizzaimage.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(933, 535);
            Controls.Add(pict_pizzaimage);
            Controls.Add(btn_calculate);
            Controls.Add(rtf_total);
            Controls.Add(rtf_tax);
            Controls.Add(rtf_subtotal);
            Controls.Add(rtf_ordersummary);
            Controls.Add(lbl_Total);
            Controls.Add(lbl_tax);
            Controls.Add(lbl_subtotal);
            Controls.Add(lbl_ordersummary);
            Controls.Add(ckb_toppings_mushrooms);
            Controls.Add(ckb_toppings_extracheese);
            Controls.Add(ckb_toppings_jalepeno);
            Controls.Add(ckb_toppings_bananapeppers);
            Controls.Add(ckb_toppings_greenolives);
            Controls.Add(ckb_toppings_blackolives);
            Controls.Add(ckb_toppings_greenpepper);
            Controls.Add(ckb_toppings_onion);
            Controls.Add(ckb_toppings_spicyitaliansausage);
            Controls.Add(ckb_toppings_canadianbacon);
            Controls.Add(ckb_toppings_sausage);
            Controls.Add(ckb_toppings_pepperoni);
            Controls.Add(lbl_toppings);
            Controls.Add(rdo_crusttype_regular);
            Controls.Add(rdo_crusttype_thick);
            Controls.Add(rdo_crusttype_thin);
            Controls.Add(lbl_crusttype);
            Controls.Add(lbl_size);
            Controls.Add(cbo_size);
            Controls.Add(lbl_BUPizzaPalace);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            Name = "Form1";
            Text = "Pizza App";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pict_pizzaimage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_BUPizzaPalace;
        private ComboBox cbo_size;
        private Label lbl_size;
        private Label lbl_crusttype;
        private RadioButton rdo_crusttype_thin;
        private RadioButton rdo_crusttype_thick;
        private RadioButton rdo_crusttype_regular;
        private Label lbl_toppings;
        private CheckBox ckb_toppings_pepperoni;
        private CheckBox ckb_toppings_sausage;
        private CheckBox ckb_toppings_canadianbacon;
        private CheckBox ckb_toppings_spicyitaliansausage;
        private CheckBox ckb_toppings_onion;
        private CheckBox ckb_toppings_greenpepper;
        private CheckBox ckb_toppings_blackolives;
        private CheckBox ckb_toppings_greenolives;
        private CheckBox ckb_toppings_bananapeppers;
        private CheckBox ckb_toppings_jalepeno;
        private CheckBox ckb_toppings_extracheese;
        private CheckBox ckb_toppings_mushrooms;
        private Label lbl_ordersummary;
        private Label lbl_subtotal;
        private Label lbl_tax;
        private Label lbl_Total;
        private RichTextBox rtf_ordersummary;
        private RichTextBox rtf_subtotal;
        private RichTextBox rtf_tax;
        private RichTextBox rtf_total;
        private Button btn_calculate;
        private PictureBox pict_pizzaimage;
    }
}