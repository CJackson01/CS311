namespace CS311_Project3_CWJ_20231105
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Click_Order_Pizza(object sender, EventArgs e)
        {
            //1. Clear form
            //rtf_ordersummary.Clear;
            //rtf_subtotal.Clear;
            //rtf_tax.Clear;
            //rtf_total.Clear;


            //2. Validate Inputs 
            if (cbo_size.Text == "Choose Size")
            {
                //Display error message
                MessageBox.Show("Please choose pizza size");

                return;
            }


            //3. Read Inputs
            double cost = 0;


            //Calc Size 

            //Small: $2.00
            //Medium: $5.00
            //Large: $10.00
            //XLarge: $15.00
            //Ginormous: $20.00


            //Size Small
            if (cbo_size.Text == "Small: $2.00")
            {
                cost = 2;
                rtf_ordersummary.AppendText("Pizza Size: Small - $2.00\n");
            }
            //Size Medium 
            else if (cbo_size.Text == "Medium: $5.00")
            {
                cost = 5;
                rtf_ordersummary.AppendText("Pizza Size: Medium - $5.00\n");
            }
            //Size Large 
            else if (cbo_size.Text == "Large: $10.00")
            {
                cost = 10;
                rtf_ordersummary.AppendText("Pizza Size: Large - $10.00\n");
            }
            //Size XLarge 
            else if (cbo_size.Text == "XLarge: $15.00")
            {
                cost = 15;
                rtf_ordersummary.AppendText("Pizza Size: X-Large - $15.00\n");
            }
            //Size Ginormous
            else if (cbo_size.Text == "Ginormous: $20.00")
            {
                cost = 20;
                rtf_ordersummary.AppendText("Pizza Size: Ginormous - $20.00\n");
            }

            //Calc Toppings 
            if (ckb_toppings_pepperoni.Checked)
            {
                cost = cost + 2;
                rtf_ordersummary.AppendText("Add Pepperoni - $2.00\n");
            }

            if (ckb_toppings_sausage.Checked)
            {
                cost = cost + 2;
                rtf_ordersummary.AppendText("Add Sausage - $2.00\n");

            }
            if (ckb_toppings_canadianbacon.Checked)
            {
                cost = cost + 2;
                rtf_ordersummary.AppendText("Add Canadian Bacon - $2.00\n");

            }
            if (ckb_toppings_spicyitaliansausage.Checked)
            {
                cost = cost + 2;
                rtf_ordersummary.AppendText("Add Spicy Italian Sausage - $2.00\n");

            }
            if (ckb_toppings_onion.Checked)
            {
                cost = cost + 1;
                rtf_ordersummary.AppendText("Add Onion - $1.00\n");

            }
            if (ckb_toppings_greenpepper.Checked)
            {
                cost = cost + 1;
                rtf_ordersummary.AppendText("Add Green Pepper - $1.00\n");

            }
            if (ckb_toppings_blackolives.Checked)
            {
                cost = cost + 1;
                rtf_ordersummary.AppendText("Add Black Olives - $1.00\n");

            }
            if (ckb_toppings_greenolives.Checked)
            {
                cost = cost + 1;
                rtf_ordersummary.AppendText("Add Green Olives - $1.00\n");

            }
            if (ckb_toppings_bananapeppers.Checked)
            {
                cost = cost + 1;
                rtf_ordersummary.AppendText("Add Banana Peppers - $1.00\n");

            }
            if (ckb_toppings_jalepeno.Checked)
            {
                cost = cost + 1;
                rtf_ordersummary.AppendText("Add Jalepeno - $1.00\n");

            }
            if (ckb_toppings_extracheese.Checked)
            {
                cost = cost + 1;
                rtf_ordersummary.AppendText("Add Extra Cheese - $1.00\n");

            }
            if (ckb_toppings_mushrooms.Checked)
            {
                cost = cost + 1;
                rtf_ordersummary.AppendText("Add Mushrooms - $1.00\n");

            }


            //4. Calculate and display 
            //Tax 
            double tax = cost * 0.06;
            rtf_tax.AppendText(String.Format("{0:C}", tax));
            rtf_subtotal.AppendText(String.Format("{0:C}", cost));
            rtf_total.AppendText(String.Format("{0:C}", cost + tax));

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}